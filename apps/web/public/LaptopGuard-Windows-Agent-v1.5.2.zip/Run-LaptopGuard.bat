@echo off
title LaptopGuard AI - Desktop Sentinel v1.5.2
echo ====================================================
echo     LaptopGuard AI - Windows Hardware Sentinel
echo ====================================================
echo Checking Python dependencies...
python -m pip install customtkinter requests websockets psutil pillow --quiet
echo Launching Sentinel GUI...
python desktop_app.py
pause
