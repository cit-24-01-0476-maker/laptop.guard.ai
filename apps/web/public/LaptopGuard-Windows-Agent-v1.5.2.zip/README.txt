LaptopGuard AI - Windows Desktop Sentinel v1.5.2
====================================================
1. Extract this entire zip archive to your laptop.
2. Double-click Run-LaptopGuard.bat.
3. Sign in with your LaptopGuard account (same as Web Dashboard).
4. Your laptop is now protected with 500ms AC disconnect watchdog,
   15-second auto-silence siren, and instant remote lock!
